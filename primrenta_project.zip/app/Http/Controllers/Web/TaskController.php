<?php

namespace App\Http\Controllers\Web;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\App;

class TaskController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');

        App::setLocale("ru");
    }


    public function getNewTask(Request $request)
    {
        $cat = $request->route('cat');
        $cat_child = $request->route('cat_child');



        return view('web.task.new');
    }

    public function getCategories()
    {
        $categories = Category::query()->get()->all();

        return view('web.task.categories', ['categories' => $categories]);
    }

    public function new_cat(Request $request)
    {



        //dd($request->route('cat_child'));

        return view('web.task.new_cat');
    }

    public function all()
    {
        return view('web.task.all');
    }
}
