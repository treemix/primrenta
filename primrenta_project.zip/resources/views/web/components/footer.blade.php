
<div class="b-footer__wrapper">
    <div class="b-footer__row-sk">
        <a href="http://sk.ru/" class="b-footer__sk" target="_blank"></a>
    </div>
    <div class="b-footer__row">
        <div class="b-footer__menu">
            <div class="b-footer-menu">
                <ul class="b-footer-menu__subsection">
                    <li class="b-footer-menu__item"> <a class="js-track-ga-event-verification" href="/verification">Как&nbsp;стать&nbsp;исполнителем</a> </li>
                    <li class="b-footer-menu__item"><a href="/profile/tariffs">Тарифы</a></li>
                    <li class="b-footer-menu__item"><a href="/faq">Частые вопросы</a></li>
                </ul>
                <ul class="b-footer-menu__subsection">
                    <li class="b-footer-menu__item"><a href="http://blog.youdo.com">Наш блог</a></li>
                    <li class="b-footer-menu__item"><a href="/reviews/authors">Отзывы заказчиков</a></li>
                </ul>
                <ul class="b-footer-menu__subsection">
                    <li class="b-footer-menu__item"><a class="js-open-site-support" href="">Служба поддержки</a></li>
                    <li class="b-footer-menu__item"><a href="/contacts">Контакты</a></li>
                </ul>
            </div>
        </div>

        <div class="b-footer__download">
            <a class="btn b-btn-download-app i-ios i-ios--RU js-appsfm-href" href="#" target="_blank"></a>
            <a class="btn b-btn-download-app i-android i-android--RU js-appsfm-href" href="#" target="_blank"></a>
        </div>
    </div>
    <div class="b-footer__row">
        <div class="b-footer__copyright">
            © 2020 PrimRenta <span>(primrenta.com, primrenta.ru, primrenta.рф)</span> · <a href="/terms">Правила сервиса</a>
        </div>
    </div>
</div>
