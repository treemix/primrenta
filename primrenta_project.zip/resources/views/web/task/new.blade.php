@extends('layouts.web')

@section('content')
<section class="layout-task-start">
    <h4 class="title">Выберите категорию задания</h4>

</section>
@endsection
