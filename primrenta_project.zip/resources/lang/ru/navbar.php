<?php

return [

    'login' => 'Вход',
    'register' => 'Регистрация',
    'and' => 'или',
    'tasks_new' => 'Создать задание',
    'tasks_all' => 'Найти задания',
    'executors_all' => 'Исполнители',
    'jobs_all' => 'Вакансии',

];
